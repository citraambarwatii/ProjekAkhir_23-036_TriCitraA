/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projekakhir;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Citra
 */
public class User extends javax.swing.JFrame {
    
    Connection conn;
    private DefaultTableModel model;
    private DefaultTableModel model2;
    

    /**
     * Creates new form User
     */
    public User() {
    initComponents();  // Inisialisasi komponen GUI terlebih dahulu
    setLocationRelativeTo(null);
    conn = koneksi.getConnection(); // Memanggil koneksi database

    tf_bayar_belanja.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyReleased(java.awt.event.KeyEvent evt) {
            HitungKembalian(); // Menambahkan event listener setelah inisialisasi
        }
    });
    btn_bayar.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        tampilkanRiwayatPesanan(); // Memanggil method untuk menampilkan riwayat pesanan
    }
    });
    


        // Inisialisasi model untuk tabel stok buku
        model = new DefaultTableModel();
        tbl_stok_buku.setModel(model);
        
        model.addColumn("Kode Buku");
        model.addColumn("Nama Buku");
        model.addColumn("Pengarang");
        model.addColumn("Penerbit");
        model.addColumn("Tahun Terbit");
        model.addColumn("Harga Buku");
        model.addColumn("Stok");
        
        model2 = new DefaultTableModel();
        tbl_kasir.setModel(model2);
        
        model2.addColumn("Kode Transaksi");
        model2.addColumn("Kode Buku");
        model2.addColumn("Nama Buku");
        model2.addColumn("Pengarang");
        model2.addColumn("Penerbit");
        model2.addColumn("Tahun Terbit");
        model2.addColumn("Harga Buku");
        model2.addColumn("Jumlah");


        // Memuat data dari tabel 'input'
        loadData();
        loadData2();
        
        tbl_kasir.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent evt) {
        int selectedRow = tbl_kasir.getSelectedRow(); // Mendapatkan baris yang dipilih
        if (selectedRow != -1) { // Pastikan ada baris yang dipilih
            tf_kode_transaksi.setText(model2.getValueAt(selectedRow, 0).toString());
            tf_kode_buku.setText(model2.getValueAt(selectedRow, 1).toString()); 
            tf_nama_buku.setText(model2.getValueAt(selectedRow, 2).toString()); 
            tf_pengarang.setText(model2.getValueAt(selectedRow, 3).toString()); 
            tf_penerbit.setText(model2.getValueAt(selectedRow, 4).toString()); 
            tf_tahun_terbit.setText(model2.getValueAt(selectedRow, 5).toString());
            tf_harga.setText(model2.getValueAt(selectedRow, 6).toString());
            tf_jumlah.setText(model2.getValueAt(selectedRow, 7).toString());
        }
    }
});
    }
    
    // Menghitung total belanja
    public void HitungTotal() {
        int totalBelanja = 0; // Variabel untuk menyimpan total belanja

        for (int i = 0; i < model2.getRowCount(); i++) {
            try {
                // Ambil nilai harga dan jumlah dari tabel
                int harga = Integer.parseInt(model2.getValueAt(i, 6).toString()); // Harga Buku
                int jumlah = Integer.parseInt(model2.getValueAt(i, 7).toString()); // Jumlah Buku

                // Kalikan harga dan jumlah, lalu tambahkan ke total
                totalBelanja += harga * jumlah;
            } catch (NumberFormatException e) {
                System.out.println("Format angka tidak valid di baris " + i + ": " + e.getMessage());
            }
        }

        // Tampilkan total belanja di textfield
        tf_total_belanja.setText(String.valueOf(totalBelanja));
    }

    // Menghitung kembalian berdasarkan uang bayar
    public void HitungKembalian() {
        try {
            // Ambil nilai dari textfield total belanja dan pembayaran
            int totalBelanja = Integer.parseInt(tf_total_belanja.getText());
            int uangBayar = Integer.parseInt(tf_bayar_belanja.getText());

            // Periksa apakah uang bayar cukup
            if (uangBayar < totalBelanja) {
                tf_kembalian.setText("Uang Anda Kurang");
            } else {
                int kembalian = uangBayar - totalBelanja;
                tf_kembalian.setText(String.valueOf(kembalian));
            }
        } catch (NumberFormatException e) {
            // Tangani input yang tidak valid
            tf_kembalian.setText("Input tidak valid");
            System.out.println("Kesalahan format angka: " + e.getMessage());
        }
    }
    public void tampilkanRiwayatPesanan() {
    // Ambil data dari form atau tabel yang ada
    String totalBelanja = tf_total_belanja.getText(); // Total Belanja
    String uangBayar = tf_bayar_belanja.getText(); // Uang Bayar
    String kembalian = tf_kembalian.getText(); // Kembalian

    // Buat string untuk menampilkan riwayat pesanan
    StringBuilder riwayatPesanan = new StringBuilder();
    
    // Menambahkan informasi buku dari tabel atau form yang dipilih
    for (int i = 0; i < model2.getRowCount(); i++) {
        String namaBuku = model2.getValueAt(i, 2).toString();
        String hargaBuku = model2.getValueAt(i, 6).toString();
        String jumlah = model2.getValueAt(i, 7).toString();
        int harga = Integer.parseInt(hargaBuku);
        int qty = Integer.parseInt(jumlah);
        int totalHarga = harga * qty; // Menghitung total harga per buku
        
        riwayatPesanan.append("\nBuku: ").append(namaBuku)
                .append("\nHarga Buku: ").append(hargaBuku)
                .append("\nJumlah: ").append(jumlah)
                .append("\nTotal Harga: ").append(totalHarga).append("\n");
    }
    
    // Menampilkan total belanja, uang bayar, dan kembalian
    riwayatPesanan.append("\nTotal Belanja: ").append(totalBelanja)
            .append("\nUang Bayar: ").append(uangBayar)
            .append("\nKembalian: ").append(kembalian);

    // Menampilkan riwayat pesanan dalam pop-up
    int option = JOptionPane.showOptionDialog(this, riwayatPesanan.toString(), "Riwayat Pesanan", 
                                              JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, 
                                              null, new Object[] { "OK" }, null);
    
    // Jika OK ditekan, reset form
    if (option == JOptionPane.OK_OPTION) {
        resetForm2(); // Memanggil method untuk reset form
        resetTabel(); // Memanggil method untuk reset tabel
    }
    }
    public void resetTabel() {
    model2.setRowCount(0); // Menghapus semua baris di tabel transaksi
}
 
    public void loadData() {
        // Mengosongkan tabel sebelum memuat data baru
        model.setRowCount(0);
        

        try {
            // Query SQL untuk mengambil data dari tabel 'input'
            String sql = "SELECT * FROM stok"; // Gunakan tabel yang sesuai
            Statement s = conn.createStatement();
            ResultSet r = s.executeQuery(sql);

            // Menambahkan data ke dalam model tabel
            while (r.next()) {
                String kodeBuku1 = r.getString("kode_buku");
                String namaBuku1 = r.getString("nama_buku");
                String pengarang1 = r.getString("pengarang");
                String penerbit1 = r.getString("penerbit");
                String tahunTerbit1 = r.getString("tahun_terbit");
                String hargaBuku1 = r.getString("harga_buku");
                String stok1 = r.getString("stok");

                // Menambahkan baris data ke tabel
                model.addRow(new Object[]{kodeBuku1, namaBuku1, pengarang1, penerbit1, tahunTerbit1, hargaBuku1, stok1});
            }

            // Menutup resources
            r.close();
            s.close();
        } catch (SQLException e) {
            // Menangani kesalahan SQL
            System.out.println("Gagal Memuat Data: " + e.getMessage());
        }
    }
    
    public void loadData2() {
        // Mengosongkan tabel sebelum memuat data baru
        model2.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) tbl_kasir.getModel();
        

        try {
            // Query SQL untuk mengambil data dari tabel 'input'
            String sql = "SELECT * FROM transaksi"; // Gunakan tabel yang sesuai
            Statement s = conn.createStatement();
            ResultSet r = s.executeQuery(sql);

            // Menambahkan data ke dalam model tabel
            while (r.next()) {
                String kodeTransaksi = r.getString("kode_transaksi");
                String kodeBuku = r.getString("kode_buku2");
                String namaBuku = r.getString("nama_buku2");
                String pengarang = r.getString("pengarang2");
                String penerbit = r.getString("penerbit2");
                String tahunTerbit = r.getString("tahun_terbit2");
                String hargaBuku = r.getString("harga2");
                String jumlah = r.getString("jumlah2");

                // Menambahkan baris data ke tabel
                model2.addRow(new Object[]{kodeTransaksi, kodeBuku, namaBuku, pengarang, penerbit, tahunTerbit, hargaBuku, jumlah});
            }

            // Menutup resources
            r.close();
            s.close();
        } catch (SQLException e) {
            // Menangani kesalahan SQL
            System.out.println("Gagal Memuat Data: " + e.getMessage());
        }
    }
    
public void autonumber(){
        try {
        conn = koneksi.getConnection();
        Statement s = conn.createStatement();
        String sql = "SELECT kode_transaksi FROM transaksi ORDER BY kode_transaksi DESC LIMIT 1";
        ResultSet r = s.executeQuery(sql);

        if (r.next()) {
            
            String kode_buku = r.getString("kode_transaksi").replaceAll("\\D", ""); // Hapus huruf
            int numKode = 0;
            try {
                numKode = Integer.parseInt(kode_buku);
            } catch (NumberFormatException e) {
                System.out.println("Format kode input tidak valid: " + e.getMessage());
            }

            // Tambahkan 1 ke kode buku terakhir
            String TR = String.valueOf(numKode + 1);
            String Nol = "";

            if (TR.length() == 1) {
                Nol = "000";
            } else if (TR.length() == 2) {
                Nol = "00";
            } else if (TR.length() == 3) {
                Nol = "0";
            }

            tf_kode_transaksi.setText("TR" + Nol + TR);
        } else {
            // Jika tidak ada data, mulai dari BK0001
            tf_kode_transaksi.setText("TR0001");
        }
        r.close();
        s.close();
    } catch (SQLException e) {
        System.out.println("autonumber error: " + e.getMessage());
    }
    }

//Simpan Data buku
    public void TambahKeranjang() {
    if (tf_kode_transaksi.getText().isEmpty() || tf_kode_buku.getText().isEmpty() || tf_nama_buku.getText().isEmpty() || tf_pengarang.getText().isEmpty() || tf_penerbit.getText().isEmpty() || tf_tahun_terbit.getText().isEmpty() || tf_harga.getText().isEmpty() || tf_jumlah.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi Data Pembelian!");
        return;
    }
    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda Yakin Akan Menambahkan Buku Ke Keranjang?", "Konfirmasi Tambah", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "INSERT INTO transaksi (kode_transaksi, kode_buku2, nama_buku2, pengarang2, penerbit2, tahun_terbit2, harga2, jumlah2 ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_kode_transaksi.getText());
            ps.setString(2, tf_kode_buku.getText());
            ps.setString(3, tf_nama_buku.getText());
            ps.setString(4, tf_pengarang.getText());
            ps.setString(5, tf_penerbit.getText());
            ps.setString(6, tf_tahun_terbit.getText());
            ps.setString(7, tf_harga.getText());
            ps.setString(8, tf_jumlah.getText());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Buku Berhasil Dimasukkan Keranjang");
            loadData2();
            resetForm();
        } catch (SQLException e) {
            System.out.println("Gagal Memasukkan Buku" + e.getMessage());
        }
    }
}
    //End Simpan Data buku
    
    //Delete Data buku
    public void HapusBuku() {
    if (tf_kode_transaksi.getText().isEmpty()) {
    JOptionPane.showMessageDialog(this, "Tolong pilih buku yang akan dihapus!");
    return;
}

int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus buku dari keranjang?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
if (confirm == JOptionPane.YES_OPTION) {
    try {
        String sql = "DELETE FROM transaksi WHERE kode_transaksi = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, tf_kode_transaksi.getText()); 
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Buku Berhasil Dihapus Dari Keranjang");
        loadData2();
        resetForm();
    } catch (SQLException e) {
        System.out.println("Gagal Menghapus Buku: " + e.getMessage());
    }
    }
}
    //End Delete Data buku
    
    public void resetForm(){
        tf_kode_transaksi.setText("");
        tf_kode_buku.setText("");
        tf_nama_buku.setText("");
        tf_pengarang.setText("");
        tf_penerbit.setText("");
        tf_tahun_terbit.setText("");
        tf_harga.setText("");
        tf_jumlah.setText("");
    }
    
    public void resetForm2() {
    tf_kode_transaksi.setText("");
    tf_kode_buku.setText("");
    tf_nama_buku.setText("");
    tf_pengarang.setText("");
    tf_penerbit.setText("");
    tf_tahun_terbit.setText("");
    tf_harga.setText("");
    tf_jumlah.setText("");
    tf_total_belanja.setText("");
    tf_bayar_belanja.setText("");
    tf_kembalian.setText("");
    
}
  



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        panel_home = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        welcome = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btn_logout_user = new javax.swing.JButton();
        panel_buku = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_stok_buku = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        panel_pembelian = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        tf_penerbit = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        tf_total_belanja = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        tf_bayar_belanja = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        tf_kembalian = new javax.swing.JTextField();
        btn_bayar = new javax.swing.JButton();
        btn_total = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        tf_tahun_terbit = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        tf_harga = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        tf_nama_buku = new javax.swing.JTextField();
        tf_kode_transaksi = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tf_pengarang = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tf_kode_buku = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        tf_jumlah = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btn_kode_transaksi = new javax.swing.JButton();
        btn_pilih_buku = new javax.swing.JButton();
        btn_keranjang_kasir = new javax.swing.JButton();
        btn_hapus_kasir = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_kasir = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TOKO BUKU");
        setPreferredSize(new java.awt.Dimension(1005, 660));

        jPanel1.setBackground(new java.awt.Color(34, 92, 127));

        jTabbedPane1.setBackground(new java.awt.Color(34, 92, 127));
        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTabbedPane1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jTabbedPane1.setOpaque(true);

        panel_home.setBackground(new java.awt.Color(255, 255, 255));
        panel_home.setOpaque(true);

        jLabel2.setBackground(new java.awt.Color(34, 92, 127));
        jLabel2.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(34, 92, 127));
        jLabel2.setText("Selamat berbelanja, dan semoga Anda menemukan cerita yang menginspirasi! ✨📖");

        welcome.setBackground(new java.awt.Color(255, 255, 255));
        welcome.setFont(new java.awt.Font("Lucida Bright", 1, 80)); // NOI18N
        welcome.setForeground(new java.awt.Color(34, 92, 127));
        welcome.setText("WELCOME");
        welcome.setOpaque(true);

        jLabel1.setBackground(new java.awt.Color(34, 92, 127));
        jLabel1.setFont(new java.awt.Font("Cooper Black", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(34, 92, 127));
        jLabel1.setText("Silahkan jelajahi koleksi kami dan dapatkan buku impian Anda dengan mudah dan nyaman.");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/buku user.png"))); // NOI18N

        btn_logout_user.setBackground(new java.awt.Color(34, 92, 127));
        btn_logout_user.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        btn_logout_user.setForeground(new java.awt.Color(255, 255, 255));
        btn_logout_user.setText("LOGOUT");
        btn_logout_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logout_userActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_homeLayout = new javax.swing.GroupLayout(panel_home);
        panel_home.setLayout(panel_homeLayout);
        panel_homeLayout.setHorizontalGroup(
            panel_homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_homeLayout.createSequentialGroup()
                .addGroup(panel_homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_homeLayout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addComponent(jLabel2))
                    .addGroup(panel_homeLayout.createSequentialGroup()
                        .addGap(233, 233, 233)
                        .addComponent(welcome))
                    .addGroup(panel_homeLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel1))
                    .addGroup(panel_homeLayout.createSequentialGroup()
                        .addGap(344, 344, 344)
                        .addComponent(jLabel4))
                    .addGroup(panel_homeLayout.createSequentialGroup()
                        .addGap(392, 392, 392)
                        .addComponent(btn_logout_user)))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        panel_homeLayout.setVerticalGroup(
            panel_homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_homeLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(welcome)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(48, 48, 48)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                .addComponent(btn_logout_user, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jTabbedPane1.addTab("HOME", panel_home);

        panel_buku.setBackground(new java.awt.Color(34, 92, 127));

        tbl_stok_buku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode Buku", "Nama Buku", "Pengarang", "Penerbit", "Tahun Terbit", "Harga", "Stok"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbl_stok_buku);

        jLabel3.setFont(new java.awt.Font("Lucida Bright", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("STOK BUKU");

        javax.swing.GroupLayout panel_bukuLayout = new javax.swing.GroupLayout(panel_buku);
        panel_buku.setLayout(panel_bukuLayout);
        panel_bukuLayout.setHorizontalGroup(
            panel_bukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 912, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bukuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(367, 367, 367))
        );
        panel_bukuLayout.setVerticalGroup(
            panel_bukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bukuLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("BUKU", panel_buku);

        panel_pembelian.setBackground(new java.awt.Color(255, 255, 255));
        panel_pembelian.setOpaque(true);

        jLabel15.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(34, 92, 127));
        jLabel15.setText("Jumlah");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel17.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(34, 92, 127));
        jLabel17.setText("Total");

        tf_total_belanja.setEditable(false);

        jLabel16.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(34, 92, 127));
        jLabel16.setText("Bayar");

        tf_bayar_belanja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_bayar_belanjaActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(34, 92, 127));
        jLabel18.setText("Kembalian");

        tf_kembalian.setEditable(false);

        btn_bayar.setBackground(new java.awt.Color(34, 92, 127));
        btn_bayar.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_bayar.setForeground(new java.awt.Color(255, 255, 255));
        btn_bayar.setText("Bayar");
        btn_bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bayarActionPerformed(evt);
            }
        });

        btn_total.setBackground(new java.awt.Color(34, 92, 127));
        btn_total.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_total.setForeground(new java.awt.Color(255, 255, 255));
        btn_total.setText("Total");
        btn_total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_totalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addComponent(tf_total_belanja, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_total, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_bayar_belanja, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_kembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 14, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jLabel16)
                    .addComponent(jLabel18)
                    .addComponent(tf_kembalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_bayar_belanja, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_total_belanja, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_bayar)
                    .addComponent(btn_total)))
        );

        jLabel12.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(34, 92, 127));
        jLabel12.setText("Penerbit");

        jLabel13.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(34, 92, 127));
        jLabel13.setText("Tahun Terbit");

        jLabel14.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(34, 92, 127));
        jLabel14.setText("Harga");

        tf_kode_transaksi.setEditable(false);

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(34, 92, 127));
        jLabel8.setText("Kode Transaksi");

        jLabel9.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(34, 92, 127));
        jLabel9.setText("Kode Buku");

        tf_kode_buku.setEditable(false);

        jLabel10.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(34, 92, 127));
        jLabel10.setText("Nama Buku");

        jLabel11.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(34, 92, 127));
        jLabel11.setText("Pengarang");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setOpaque(true);
        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        btn_kode_transaksi.setBackground(new java.awt.Color(34, 92, 127));
        btn_kode_transaksi.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_kode_transaksi.setForeground(new java.awt.Color(255, 255, 255));
        btn_kode_transaksi.setText("Kode Transaksi");
        btn_kode_transaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kode_transaksiActionPerformed(evt);
            }
        });
        jPanel3.add(btn_kode_transaksi);

        btn_pilih_buku.setBackground(new java.awt.Color(34, 92, 127));
        btn_pilih_buku.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_pilih_buku.setForeground(new java.awt.Color(255, 255, 255));
        btn_pilih_buku.setText("Pilih Buku");
        btn_pilih_buku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pilih_bukuActionPerformed(evt);
            }
        });
        jPanel3.add(btn_pilih_buku);

        btn_keranjang_kasir.setBackground(new java.awt.Color(34, 92, 127));
        btn_keranjang_kasir.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_keranjang_kasir.setForeground(new java.awt.Color(255, 255, 255));
        btn_keranjang_kasir.setText("Tambah Keranjang");
        btn_keranjang_kasir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_keranjang_kasirActionPerformed(evt);
            }
        });
        jPanel3.add(btn_keranjang_kasir);

        btn_hapus_kasir.setBackground(new java.awt.Color(34, 92, 127));
        btn_hapus_kasir.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_hapus_kasir.setForeground(new java.awt.Color(255, 255, 255));
        btn_hapus_kasir.setText("Hapus");
        btn_hapus_kasir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapus_kasirActionPerformed(evt);
            }
        });
        jPanel3.add(btn_hapus_kasir);

        tbl_kasir.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode Transaksi", "Kode Buku", "Nama Buku", "Pengarang", "Penerbit", "Terbit", "Harga", "Jumlah"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tbl_kasir);

        javax.swing.GroupLayout panel_pembelianLayout = new javax.swing.GroupLayout(panel_pembelian);
        panel_pembelian.setLayout(panel_pembelianLayout);
        panel_pembelianLayout.setHorizontalGroup(
            panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_pembelianLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tf_kode_transaksi)
                    .addComponent(tf_kode_buku, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tf_pengarang)
                    .addComponent(tf_nama_buku, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panel_pembelianLayout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf_tahun_terbit, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_pembelianLayout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tf_penerbit, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panel_pembelianLayout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tf_harga, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_pembelianLayout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(18, 18, 18)
                        .addComponent(tf_jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(41, 41, 41))
            .addGroup(panel_pembelianLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panel_pembelianLayout.setVerticalGroup(
            panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_pembelianLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_pembelianLayout.createSequentialGroup()
                        .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10)
                            .addComponent(jLabel12)
                            .addComponent(jLabel14)
                            .addComponent(tf_nama_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_harga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_penerbit, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panel_pembelianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel13)
                            .addComponent(tf_pengarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_kode_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel15)
                            .addComponent(tf_jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_tahun_terbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(tf_kode_transaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 412, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jTabbedPane1.addTab("PEMBELIAN", panel_pembelian);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_keranjang_kasirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_keranjang_kasirActionPerformed
        // TODO add your handling code here:
        TambahKeranjang();
    }//GEN-LAST:event_btn_keranjang_kasirActionPerformed

    private void btn_kode_transaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kode_transaksiActionPerformed
        // TODO add your handling code here:
        autonumber();
    }//GEN-LAST:event_btn_kode_transaksiActionPerformed

    private void btn_pilih_bukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pilih_bukuActionPerformed
        // TODO add your handling code here:
        // Membuka dialog tabel buku
    Stok stok = new Stok();
    stok.setVisible(true);

    // Membuat dialog pop-up
    JDialog dialog = new JDialog();
    dialog.setTitle("Tabel Buku");

    // Menambahkan tabel tbl_stok ke dalam JScrollPane
    JTable tblStok = stok.getTblStok();
    JScrollPane scrollPane = new JScrollPane(tblStok);
    dialog.add(scrollPane);

    // Tambahkan listener untuk menangkap klik pada tabel
    tblStok.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent evt) {
            int selectedRow = tblStok.getSelectedRow(); // Mendapatkan baris yang dipilih
            if (selectedRow != -1) {
                // Mendapatkan data dari tabel dan mengisi TextField di Input
                tf_kode_buku.setText(tblStok.getValueAt(selectedRow, 0).toString());
                tf_nama_buku.setText(tblStok.getValueAt(selectedRow, 1).toString());
                tf_pengarang.setText(tblStok.getValueAt(selectedRow, 2).toString());
                tf_penerbit.setText(tblStok.getValueAt(selectedRow, 3).toString());
                tf_tahun_terbit.setText(tblStok.getValueAt(selectedRow, 4).toString());
                tf_harga.setText(tblStok.getValueAt(selectedRow, 5).toString());

                // Menutup dialog setelah data diambil
                dialog.dispose();
            }
        }
    });

    // Mengatur ukuran dan menampilkan dialog
    dialog.setSize(600, 400);
    dialog.setLocationRelativeTo(null); // Memposisikan dialog di tengah layar
    dialog.setVisible(true);
    }//GEN-LAST:event_btn_pilih_bukuActionPerformed
    
    private void btn_hapus_kasirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapus_kasirActionPerformed
        // TODO add your handling code here:
        HapusBuku();
    }//GEN-LAST:event_btn_hapus_kasirActionPerformed

    private void btn_bayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_bayarActionPerformed
       
    }//GEN-LAST:event_btn_bayarActionPerformed

    private void btn_totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_totalActionPerformed
        // TODO add your handling code here:
        HitungTotal();
    }//GEN-LAST:event_btn_totalActionPerformed

    private void tf_bayar_belanjaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_bayar_belanjaActionPerformed
        // TODO add your handling code here:
        tf_bayar_belanja.addKeyListener(new java.awt.event.KeyAdapter() {
    @Override
    public void keyReleased(java.awt.event.KeyEvent evt) {
        HitungKembalian();
    }
});

    }//GEN-LAST:event_tf_bayar_belanjaActionPerformed

    private void btn_logout_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logout_userActionPerformed
        // TODO add your handling code here:
        SignUp signupFrame = new SignUp();
        signupFrame.setVisible(true);
        signupFrame.pack();
        signupFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btn_logout_userActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new User().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_bayar;
    private javax.swing.JButton btn_hapus_kasir;
    private javax.swing.JButton btn_keranjang_kasir;
    private javax.swing.JButton btn_kode_transaksi;
    private javax.swing.JButton btn_logout_user;
    private javax.swing.JButton btn_pilih_buku;
    private javax.swing.JButton btn_total;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel panel_buku;
    private javax.swing.JPanel panel_home;
    private javax.swing.JPanel panel_pembelian;
    private javax.swing.JTable tbl_kasir;
    private javax.swing.JTable tbl_stok_buku;
    private javax.swing.JTextField tf_bayar_belanja;
    private javax.swing.JTextField tf_harga;
    private javax.swing.JTextField tf_jumlah;
    private javax.swing.JTextField tf_kembalian;
    private javax.swing.JTextField tf_kode_buku;
    private javax.swing.JTextField tf_kode_transaksi;
    private javax.swing.JTextField tf_nama_buku;
    private javax.swing.JTextField tf_penerbit;
    private javax.swing.JTextField tf_pengarang;
    private javax.swing.JTextField tf_tahun_terbit;
    private javax.swing.JTextField tf_total_belanja;
    private javax.swing.JLabel welcome;
    // End of variables declaration//GEN-END:variables
}
