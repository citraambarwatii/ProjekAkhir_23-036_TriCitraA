/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projekakhir;

//import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Citra
 */
public class Input extends javax.swing.JInternalFrame {
    Connection conn;
    private DefaultTableModel model;
    /**
     * Creates new form Input
     */
    public Input() {
        initComponents();
        conn = koneksi.getConnection();

        model = new DefaultTableModel();
        tbl_input.setModel(model);
        
        model.addColumn("Kode Input");
        model.addColumn("Kode Buku");
        model.addColumn("Nama Buku");
        model.addColumn("Pengarang");
        model.addColumn("Penerbit");
        model.addColumn("Tahun Terbit");
        model.addColumn("Supplier");
        model.addColumn("Stok");
        model.addColumn("Harga Jual");
        model.addColumn("Harga Beli");
        loadData();
        tbl_input.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent evt) {
        int selectedRow = tbl_input.getSelectedRow(); // Mendapatkan baris yang dipilih
        if (selectedRow != -1) { // Pastikan ada baris yang dipilih
            tf_kode_input.setText(model.getValueAt(selectedRow, 0).toString());
            tf_kode_buku.setText(model.getValueAt(selectedRow, 1).toString()); 
            tf_nama_buku.setText(model.getValueAt(selectedRow, 2).toString()); 
            tf_pengarang.setText(model.getValueAt(selectedRow, 3).toString()); 
            tf_penerbit.setText(model.getValueAt(selectedRow, 4).toString()); 
            tf_tahun_terbit.setText(model.getValueAt(selectedRow, 5).toString());
            tf_nama_supplier.setText(model.getValueAt(selectedRow, 6).toString());
            tf_stok.setText(model.getValueAt(selectedRow, 7).toString());
            tf_harga_beli.setText(model.getValueAt(selectedRow, 8).toString()); 
            tf_harga_jual.setText(model.getValueAt(selectedRow, 9).toString());
            
        }
    }
});
    }
    
    //Load Data Tabel stok
    public void loadData() {
        DefaultTableModel model = (DefaultTableModel) tbl_input.getModel();
    model.setRowCount(0); // Hapus data lama
    try {
        String sql = "SELECT * FROM input";
        Statement s = conn.createStatement();
        ResultSet r = s.executeQuery(sql);
        while (r.next()) {
            String kodeInput = r.getString("kode_input");
            String kodeBuku = r.getString("kode_buku");
            String namaBuku = r.getString("nama_buku");
            String pengarang = r.getString("pengarang");
            String penerbit = r.getString("penerbit");
            String tahunTerbit = r.getString("tahun_terbit");
            String supplier = r.getString("supplier");
            String stok = r.getString("stok");
            String hargaBeli = r.getString("harga_beli");
            String hargaJual = r.getString("harga_jual");
            model.addRow(new Object[]{kodeInput, kodeBuku, namaBuku, pengarang, penerbit, tahunTerbit, supplier, stok, hargaBeli, hargaJual});
        }
        r.close();
        s.close();
    } catch (SQLException e) {
        System.out.println("Gagal Memuat Data: " + e.getMessage());
    }
    }
    //End Load Data Tabel stok
    
    public void autonumber(){
        try {
        conn = koneksi.getConnection();
        Statement s = conn.createStatement();
        String sql = "SELECT kode_input FROM input ORDER BY kode_input DESC LIMIT 1";
        ResultSet r = s.executeQuery(sql);

        if (r.next()) {
            // Ambil angka di akhir kode_supp, apapun prefiksnya
            String kode_buku = r.getString("kode_input").replaceAll("\\D", ""); // Hapus huruf
            int numKode = 0;
            try {
                numKode = Integer.parseInt(kode_buku);
            } catch (NumberFormatException e) {
                System.out.println("Format kode input tidak valid: " + e.getMessage());
            }

            // Tambahkan 1 ke kode buku terakhir
            String INP = String.valueOf(numKode + 1);
            String Nol = "";

            if (INP.length() == 1) {
                Nol = "000";
            } else if (INP.length() == 2) {
                Nol = "00";
            } else if (INP.length() == 3) {
                Nol = "0";
            }

            tf_kode_input.setText("INP" + Nol + INP);
        } else {
            // Jika tidak ada data, mulai dari BK0001
            tf_kode_input.setText("INP0001");
        }
        r.close();
        s.close();
    } catch (SQLException e) {
        System.out.println("autonumber error: " + e.getMessage());
    }
    }
    
    //Simpan Data buku
    public void SimpanDataInput() {
    if (tf_kode_input.getText().isEmpty() || tf_kode_buku.getText().isEmpty() || tf_nama_buku.getText().isEmpty() || tf_pengarang.getText().isEmpty() || tf_penerbit.getText().isEmpty() || tf_tahun_terbit.getText().isEmpty() || tf_nama_supplier.getText().isEmpty() || tf_stok.getText().isEmpty()|| tf_harga_beli.getText().isEmpty()|| tf_harga_jual.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi Data input!");
        return;
    }
    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menambahkan data input?", "Konfirmasi Tambah", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "INSERT INTO input (kode_input, kode_buku, nama_buku, pengarang, penerbit, tahun_terbit, supplier, stok, harga_jual, harga_beli ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_kode_input.getText());
            ps.setString(2, tf_kode_buku.getText());
            ps.setString(3, tf_nama_buku.getText());
            ps.setString(4, tf_pengarang.getText());
            ps.setString(5, tf_penerbit.getText());
            ps.setString(6, tf_tahun_terbit.getText());
            ps.setString(7, tf_nama_supplier.getText());
            ps.setString(8, tf_stok.getText());
            ps.setString(9, tf_harga_beli.getText());
            ps.setString(10, tf_harga_jual.getText());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Berhasil Disimpan");
            loadData();
            resetForm();
        } catch (SQLException e) {
            System.out.println("Gagal Menyimpan Data" + e.getMessage());
        }
    }
}
    //End Simpan Data buku
    
    //Update Data buku
    public void PerbaruiDataInput() {
     if (tf_kode_buku.getText().isEmpty() ||tf_nama_buku.getText().isEmpty() || tf_pengarang.getText().isEmpty() || tf_penerbit.getText().isEmpty() || tf_tahun_terbit.getText().isEmpty() || tf_nama_supplier.getText().isEmpty() || tf_stok.getText().isEmpty() || tf_harga_beli.getText().isEmpty() || tf_harga_jual.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi data input Yang Akan Diubah!");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin mengubah data input?", "Konfirmasi Ubah", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "UPDATE input SET supplier = ?, harga_jual = ? WHERE kode_input = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_nama_supplier.getText());
            ps.setString(2, tf_harga_jual.getText());
            ps.setString(3, tf_kode_input.getText()); // Menggunakan kode buku sebagai kondisi
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Berhasil Diubah");
            loadData();
            resetForm();
        } catch (SQLException e) {
            System.out.println("Gagal Menyimpan Data: " + e.getMessage());
        }
    }
}
    //End Update Data buku
    
    //Delete Data buku
    public void HapusDataInput() {
    if (tf_kode_input.getText().isEmpty()) {
    JOptionPane.showMessageDialog(this, "Tolong pilih yang akan dihapus!");
    return;
}

int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus data input?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
if (confirm == JOptionPane.YES_OPTION) {
    try {
        String sql = "DELETE FROM input WHERE kode_input = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, tf_kode_input.getText()); // Menggunakan setString untuk kode supplier
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Data Berhasil Dihapus");
        loadData();
        resetForm();
    } catch (SQLException e) {
        System.out.println("Gagal Menghapus Data Supplier: " + e.getMessage());
    }
    }
}
    //End Delete Data buku
    
    public void resetForm(){
        tf_kode_input.setText("");
        tf_kode_buku.setText("");
        tf_nama_buku.setText("");
        tf_pengarang.setText("");
        tf_penerbit.setText("");
        tf_tahun_terbit.setText("");
        tf_nama_supplier.setText("");
        tf_harga_jual.setText("");
        tf_harga_beli.setText("");
        tf_stok.setText("");
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tf_nama_buku = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        tf_penerbit = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        tf_tahun_terbit = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        tf_kode_input = new javax.swing.JTextField();
        tf_kode_buku = new javax.swing.JTextField();
        tf_pengarang = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        tf_stok = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        tf_harga_beli = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        tf_harga_jual = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_input = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btn_tambah_input = new javax.swing.JButton();
        btn_buku_input = new javax.swing.JButton();
        btn_supplier = new javax.swing.JButton();
        btn_simpan_input = new javax.swing.JButton();
        btn_perbarui_input = new javax.swing.JButton();
        btn_hapus_input = new javax.swing.JButton();
        tf_nama_supplier = new javax.swing.JTextField();

        setTitle("INPUT");
        setPreferredSize(new java.awt.Dimension(888, 427));

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(34, 92, 127));
        jLabel8.setText("Kode Input");

        jLabel9.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(34, 92, 127));
        jLabel9.setText("Kode Buku");

        jLabel10.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(34, 92, 127));
        jLabel10.setText("Nama Buku");

        jLabel11.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(34, 92, 127));
        jLabel11.setText("Pengarang");

        jLabel12.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(34, 92, 127));
        jLabel12.setText("Penerbit");

        jLabel13.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(34, 92, 127));
        jLabel13.setText("Tahun Terbit");

        jLabel14.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(34, 92, 127));
        jLabel14.setText("Supllier");

        tf_kode_input.setEditable(false);

        tf_kode_buku.setEditable(false);
        tf_kode_buku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_kode_bukuActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(34, 92, 127));
        jLabel15.setText("Stok");

        jLabel16.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(34, 92, 127));
        jLabel16.setText("Harga Jual");

        jLabel17.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(34, 92, 127));
        jLabel17.setText("Harga Beli");

        tbl_input.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode Transaksi", "Kode Buku", "Nama Buku", "Pengarang", "Penerbit", "Terbit", "Suplplier", "Jumlah", "Harga Jual", "Harga Beli"
            }
        ));
        tbl_input.setToolTipText("");
        tbl_input.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tbl_inputAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(tbl_input);

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        btn_tambah_input.setBackground(new java.awt.Color(34, 92, 127));
        btn_tambah_input.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_tambah_input.setForeground(new java.awt.Color(255, 255, 255));
        btn_tambah_input.setText("Kode Input");
        btn_tambah_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambah_inputActionPerformed(evt);
            }
        });
        jPanel1.add(btn_tambah_input);

        btn_buku_input.setBackground(new java.awt.Color(34, 92, 127));
        btn_buku_input.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_buku_input.setForeground(new java.awt.Color(255, 255, 255));
        btn_buku_input.setText("Tabel Buku");
        btn_buku_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buku_inputActionPerformed(evt);
            }
        });
        jPanel1.add(btn_buku_input);

        btn_supplier.setBackground(new java.awt.Color(34, 92, 127));
        btn_supplier.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_supplier.setForeground(new java.awt.Color(255, 255, 255));
        btn_supplier.setText("Supplier");
        btn_supplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_supplierActionPerformed(evt);
            }
        });
        jPanel1.add(btn_supplier);

        btn_simpan_input.setBackground(new java.awt.Color(34, 92, 127));
        btn_simpan_input.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_simpan_input.setForeground(new java.awt.Color(255, 255, 255));
        btn_simpan_input.setText("Simpan");
        btn_simpan_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpan_inputActionPerformed(evt);
            }
        });
        jPanel1.add(btn_simpan_input);

        btn_perbarui_input.setBackground(new java.awt.Color(34, 92, 127));
        btn_perbarui_input.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_perbarui_input.setForeground(new java.awt.Color(255, 255, 255));
        btn_perbarui_input.setText("Perbarui");
        btn_perbarui_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_perbarui_inputActionPerformed(evt);
            }
        });
        jPanel1.add(btn_perbarui_input);

        btn_hapus_input.setBackground(new java.awt.Color(34, 92, 127));
        btn_hapus_input.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_hapus_input.setForeground(new java.awt.Color(255, 255, 255));
        btn_hapus_input.setText("Hapus");
        btn_hapus_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapus_inputActionPerformed(evt);
            }
        });
        jPanel1.add(btn_hapus_input);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 869, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_kode_input, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_kode_buku, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tf_nama_buku, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_pengarang, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tf_tahun_terbit, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_penerbit, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(25, 25, 25)
                                .addComponent(tf_stok, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tf_nama_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel17))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel16)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(tf_harga_jual)
                            .addComponent(tf_harga_beli, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10)
                            .addComponent(jLabel12)
                            .addComponent(tf_nama_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel13)
                            .addComponent(tf_pengarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tf_kode_input, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf_kode_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf_penerbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(tf_nama_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf_tahun_terbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addComponent(tf_harga_beli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(tf_harga_jual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_stok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void tf_kode_bukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_kode_bukuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_kode_bukuActionPerformed

    private void btn_buku_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buku_inputActionPerformed
        // TODO add your handling code here:
// Membuat instance dari kelas Stok
    Stok stok = new Stok();
    stok.setVisible(true);

    // Membuat dialog pop-up
    JDialog dialog = new JDialog();
    dialog.setTitle("Tabel Buku");

    // Menambahkan tabel tbl_stok ke dalam JScrollPane
    JTable tblStok = stok.getTblStok();
    JScrollPane scrollPane = new JScrollPane(tblStok);
    dialog.add(scrollPane);

    // Tambahkan listener untuk menangkap klik pada tabel
    tblStok.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent evt) {
            int selectedRow = tblStok.getSelectedRow(); // Mendapatkan baris yang dipilih
            if (selectedRow != -1) {
                // Mendapatkan data dari tabel dan mengisi TextField di Input
                tf_kode_buku.setText(tblStok.getValueAt(selectedRow, 0).toString());
                tf_nama_buku.setText(tblStok.getValueAt(selectedRow, 1).toString());
                tf_pengarang.setText(tblStok.getValueAt(selectedRow, 2).toString());
                tf_penerbit.setText(tblStok.getValueAt(selectedRow, 3).toString());
                tf_tahun_terbit.setText(tblStok.getValueAt(selectedRow, 4).toString());
                tf_harga_beli.setText(tblStok.getValueAt(selectedRow, 5).toString());
                tf_stok.setText(tblStok.getValueAt(selectedRow, 6).toString());

                // Menutup dialog setelah data diambil
                dialog.dispose();
            }
        }
    });

    // Mengatur ukuran dan menampilkan dialog
    dialog.setSize(600, 400);
    dialog.setLocationRelativeTo(null); // Memposisikan dialog di tengah layar
    dialog.setVisible(true);
    }//GEN-LAST:event_btn_buku_inputActionPerformed

    private void btn_tambah_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambah_inputActionPerformed
        // TODO add your handling code here:
        autonumber();
    }//GEN-LAST:event_btn_tambah_inputActionPerformed

    private void btn_supplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_supplierActionPerformed
        // TODO add your handling code here
      // Membuat instance dari kelas Supplier
    Supplier supplier = new Supplier();
    supplier.setVisible(true);

    // Membuat dialog pop-up
    JDialog dialog = new JDialog();
    dialog.setTitle("Tabel Supplier");

    // Menambahkan tabel tbl_supplier ke dalam JScrollPane
    JTable tblSupplier = supplier.getTblSupplier();
    JScrollPane scrollPane = new JScrollPane(tblSupplier);
    dialog.add(scrollPane);

    // Tambahkan listener untuk menangkap klik pada tabel
    tblSupplier.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent evt) {
            int selectedRow = tblSupplier.getSelectedRow(); // Mendapatkan baris yang dipilih
            if (selectedRow != -1) {
                // Mendapatkan data dari tabel dan mengisi TextField di Input
                tf_nama_supplier.setText(tblSupplier.getValueAt(selectedRow, 1).toString());

                // Menutup dialog setelah data diambil
                dialog.dispose();
            }
        }
    });

    // Mengatur ukuran dan menampilkan dialog
    dialog.setSize(600, 400);
    dialog.setLocationRelativeTo(null); // Memposisikan dialog di tengah layar
    dialog.setVisible(true);
    }//GEN-LAST:event_btn_supplierActionPerformed

    private void btn_hapus_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapus_inputActionPerformed
        // TODO add your handling code here:
        HapusDataInput();
    }//GEN-LAST:event_btn_hapus_inputActionPerformed

    private void btn_perbarui_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_perbarui_inputActionPerformed
        // TODO add your handling code here:
        PerbaruiDataInput();
    }//GEN-LAST:event_btn_perbarui_inputActionPerformed

    private void btn_simpan_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpan_inputActionPerformed
        // TODO add your handling code here:
        SimpanDataInput();

    }//GEN-LAST:event_btn_simpan_inputActionPerformed

    private void tbl_inputAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tbl_inputAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_tbl_inputAncestorAdded


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buku_input;
    private javax.swing.JButton btn_hapus_input;
    private javax.swing.JButton btn_perbarui_input;
    private javax.swing.JButton btn_simpan_input;
    private javax.swing.JButton btn_supplier;
    private javax.swing.JButton btn_tambah_input;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_input;
    private javax.swing.JTextField tf_harga_beli;
    private javax.swing.JTextField tf_harga_jual;
    private javax.swing.JTextField tf_kode_buku;
    private javax.swing.JTextField tf_kode_input;
    private javax.swing.JTextField tf_nama_buku;
    private javax.swing.JTextField tf_nama_supplier;
    private javax.swing.JTextField tf_penerbit;
    private javax.swing.JTextField tf_pengarang;
    private javax.swing.JTextField tf_stok;
    private javax.swing.JTextField tf_tahun_terbit;
    // End of variables declaration//GEN-END:variables
}
