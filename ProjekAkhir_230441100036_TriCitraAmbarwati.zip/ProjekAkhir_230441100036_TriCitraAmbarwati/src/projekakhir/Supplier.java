/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projekakhir;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTable;
/**
 *
 * @author Citra
 */
public class Supplier extends javax.swing.JInternalFrame {
    Connection conn;
    private DefaultTableModel model;

    /**
     * Creates new form Supplier
     */
    public Supplier() {
        initComponents();
        conn = koneksi.getConnection();

        model = new DefaultTableModel();
        tbl_supplier.setModel(model);
        
        model.addColumn("Kode Supplier");
        model.addColumn("Nama");
        model.addColumn("No Telepon");
        model.addColumn("Alamat");
        
        loadData();
        
            tbl_supplier.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent evt) {
        int selectedRow = tbl_supplier.getSelectedRow(); // Mendapatkan baris yang dipilih
        if (selectedRow != -1) { // Pastikan ada baris yang dipilih
            tf_kode_supplier.setText(model.getValueAt(selectedRow, 0).toString()); 
            tf_nama_supplier.setText(model.getValueAt(selectedRow, 1).toString()); 
            tf_notelp_supplier.setText(model.getValueAt(selectedRow, 2).toString()); 
            tf_alamat_supplier.setText(model.getValueAt(selectedRow, 3).toString()); 
        }
    }
});
}
        //Load Data Tabel Supplier
    private void loadData() {
        DefaultTableModel model = (DefaultTableModel) tbl_supplier.getModel();
    model.setRowCount(0); // Hapus data lama
    try {
        String sql = "SELECT * FROM supplier";
        Statement s = conn.createStatement();
        ResultSet r = s.executeQuery(sql);
        while (r.next()) {
            String kodeSupp = r.getString("kode_supp");
            String namaSupp = r.getString("nama_supp");
            String notelpSupp = r.getString("notelp_supp");
            String alamatSupp = r.getString("alamat_supp");
            model.addRow(new Object[]{kodeSupp, namaSupp, notelpSupp, alamatSupp});
        }
        r.close();
        s.close();
    } catch (SQLException e) {
        System.out.println("Gagal Memuat Data: " + e.getMessage());
    }
    }
    //End Load Data Tabel Supplier
 private void autonumber(){
        try {
        conn = koneksi.getConnection();
        Statement s = conn.createStatement();
        String sql = "SELECT kode_supp FROM supplier ORDER BY kode_supp DESC LIMIT 1";
        ResultSet r = s.executeQuery(sql);

        if (r.next()) {
            // Ambil angka di akhir kode_supp, apapun prefiksnya
            String kode_supp = r.getString("kode_supp").replaceAll("\\D", ""); // Hapus huruf
            int numKode = 0;
            try {
                numKode = Integer.parseInt(kode_supp);
            } catch (NumberFormatException e) {
                System.out.println("Format kode supplier tidak valid: " + e.getMessage());
            }

            // Tambahkan 1 ke kode supplier terakhir
            String SUPP = String.valueOf(numKode + 1);
            String Nol = "";

            if (SUPP.length() == 1) {
                Nol = "000";
            } else if (SUPP.length() == 2) {
                Nol = "00";
            } else if (SUPP.length() == 3) {
                Nol = "0";
            }

            tf_kode_supplier.setText("SUPP" + Nol + SUPP);
        } else {
            // Jika tidak ada data, mulai dari SUPP0001
            tf_kode_supplier.setText("SUPP0001");
        }
        r.close();
        s.close();
    } catch (SQLException e) {
        System.out.println("autonumber error: " + e.getMessage());
    }
    }
    
    
    //Simpan Data Supplier
    private void SimpanDataSupplier() {
    if (tf_nama_supplier.getText().isEmpty() || tf_notelp_supplier.getText().isEmpty() || tf_alamat_supplier.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi Data Supplier!");
        return;
    }
    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menambahkan data Supplier?", "Konfirmasi Tambah", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "INSERT INTO supplier (kode_supp, nama_supp, notelp_supp, alamat_supp ) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_kode_supplier.getText());
            ps.setString(2, tf_nama_supplier.getText());
            ps.setString(3, tf_notelp_supplier.getText());
            ps.setString(4, tf_alamat_supplier.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Berhasil Disimpan");
            loadData();
            resetForm();
        } catch (SQLException e) {
            System.out.println("Gagal Menyimpan Data" + e.getMessage());
        }
    }
}
    //End Simpan Data Suplier
    
    //Update Data Supplier
    private void PerbaruiDataSupplier() {
     if (tf_nama_supplier.getText().isEmpty() || tf_notelp_supplier.getText().isEmpty() || tf_alamat_supplier.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi data Supplier Yang Akan Diubah!");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin mengubah data supplier?", "Konfirmasi Ubah", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "UPDATE supplier SET nama_supp = ?, notelp_supp = ?, alamat_supp = ? WHERE kode_supp = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_nama_supplier.getText());
            ps.setString(2, tf_notelp_supplier.getText());
            ps.setString(3, tf_alamat_supplier.getText());
            ps.setString(4, tf_kode_supplier.getText()); // Menggunakan kode supplier sebagai kondisi
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Berhasil Diubah");
            loadData();
            resetForm();
        } catch (SQLException e) {
            System.out.println("Gagal Menyimpan Data: " + e.getMessage());
        }
    }
}
    //End Update Data Supplier
    
    //Delete Data Karyawan
    private void HapusDataSupplier() {
    if (tf_kode_supplier.getText().isEmpty()) {
    JOptionPane.showMessageDialog(this, "Tolong pilih supplier yang akan dihapus!");
    return;
}

int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus data supplier?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
if (confirm == JOptionPane.YES_OPTION) {
    try {
        String sql = "DELETE FROM supplier WHERE kode_supp = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, tf_kode_supplier.getText()); // Menggunakan setString untuk kode supplier
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Data Berhasil Dihapus");
        loadData();
        resetForm();
    } catch (SQLException e) {
        System.out.println("Gagal Menghapus Data Supplier: " + e.getMessage());
    }
    }
}
    //End Delete Data Supplier
    
    public JTable getTblSupplier() {
    return tbl_supplier;
}

    
    private void resetForm(){
        tf_kode_supplier.setText("");
        tf_nama_supplier.setText("");
        tf_notelp_supplier.setText("");
        tf_alamat_supplier.setText("");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_supplier = new javax.swing.JTable();
        tf_kode_supplier = new javax.swing.JTextField();
        tf_notelp_supplier = new javax.swing.JTextField();
        tf_nama_supplier = new javax.swing.JTextField();
        tf_alamat_supplier = new javax.swing.JTextField();
        tf_search_supplier = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        btn_tambah_supplier = new javax.swing.JButton();
        btn_simpan_supplier = new javax.swing.JButton();
        btn_perbarui_supplier = new javax.swing.JButton();
        btn_hapus_supplier = new javax.swing.JButton();

        setTitle("SUPPLIER");
        setPreferredSize(new java.awt.Dimension(888, 427));

        jLabel6.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(34, 92, 127));
        jLabel6.setText("Kode Supplier");

        jLabel7.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(34, 92, 127));
        jLabel7.setText("Nama");

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(34, 92, 127));
        jLabel8.setText("No. Telepon");

        jLabel9.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(34, 92, 127));
        jLabel9.setText("Alamat");

        tbl_supplier.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Kode Supplier", "Nama", "No. Telepon", "Alamat"
            }
        ));
        jScrollPane1.setViewportView(tbl_supplier);

        tf_kode_supplier.setEditable(false);

        tf_search_supplier.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf_search_supplier.setText("SEARCH BERDASARKAN NAMA");
        tf_search_supplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_search_supplierActionPerformed(evt);
            }
        });

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        btn_tambah_supplier.setBackground(new java.awt.Color(34, 92, 127));
        btn_tambah_supplier.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_tambah_supplier.setForeground(new java.awt.Color(255, 255, 255));
        btn_tambah_supplier.setText("Kode Supplier");
        btn_tambah_supplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambah_supplierActionPerformed(evt);
            }
        });
        jPanel1.add(btn_tambah_supplier);

        btn_simpan_supplier.setBackground(new java.awt.Color(34, 92, 127));
        btn_simpan_supplier.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_simpan_supplier.setForeground(new java.awt.Color(255, 255, 255));
        btn_simpan_supplier.setText("Simpan");
        btn_simpan_supplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpan_supplierActionPerformed(evt);
            }
        });
        jPanel1.add(btn_simpan_supplier);

        btn_perbarui_supplier.setBackground(new java.awt.Color(34, 92, 127));
        btn_perbarui_supplier.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_perbarui_supplier.setForeground(new java.awt.Color(255, 255, 255));
        btn_perbarui_supplier.setText("Perbarui");
        btn_perbarui_supplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_perbarui_supplierActionPerformed(evt);
            }
        });
        jPanel1.add(btn_perbarui_supplier);

        btn_hapus_supplier.setBackground(new java.awt.Color(34, 92, 127));
        btn_hapus_supplier.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_hapus_supplier.setForeground(new java.awt.Color(255, 255, 255));
        btn_hapus_supplier.setText("Hapus");
        btn_hapus_supplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapus_supplierActionPerformed(evt);
            }
        });
        jPanel1.add(btn_hapus_supplier);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tf_kode_supplier)
                            .addComponent(tf_nama_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(62, 62, 62)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tf_notelp_supplier)
                            .addComponent(tf_alamat_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 124, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_search_supplier, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(tf_notelp_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(tf_alamat_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(tf_kode_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(tf_nama_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tf_search_supplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tf_search_supplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_search_supplierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_search_supplierActionPerformed

    private void btn_perbarui_supplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_perbarui_supplierActionPerformed
        // TODO add your handling code here:
        PerbaruiDataSupplier();
    }//GEN-LAST:event_btn_perbarui_supplierActionPerformed

    private void btn_tambah_supplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambah_supplierActionPerformed
        // TODO add your handling code here:
        autonumber();
    }//GEN-LAST:event_btn_tambah_supplierActionPerformed

    private void btn_simpan_supplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpan_supplierActionPerformed
        // TODO add your handling code here:
        SimpanDataSupplier();
    }//GEN-LAST:event_btn_simpan_supplierActionPerformed

    private void btn_hapus_supplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapus_supplierActionPerformed
        // TODO add your handling code here:
        HapusDataSupplier();
    }//GEN-LAST:event_btn_hapus_supplierActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_hapus_supplier;
    private javax.swing.JButton btn_perbarui_supplier;
    private javax.swing.JButton btn_simpan_supplier;
    private javax.swing.JButton btn_tambah_supplier;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_supplier;
    private javax.swing.JTextField tf_alamat_supplier;
    private javax.swing.JTextField tf_kode_supplier;
    private javax.swing.JTextField tf_nama_supplier;
    private javax.swing.JTextField tf_notelp_supplier;
    private javax.swing.JTextField tf_search_supplier;
    // End of variables declaration//GEN-END:variables
}
