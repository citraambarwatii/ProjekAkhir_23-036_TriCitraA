/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projekakhir;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTable;

/**
 *
 * @author Citra
 */
public class Stok extends javax.swing.JInternalFrame {
    Connection conn;
    private DefaultTableModel model;
    /**
     * Creates new form Stok
     */
    public Stok() {
        initComponents();
        conn = koneksi.getConnection();

        model = new DefaultTableModel();
        tbl_stok.setModel(model);
        
        model.addColumn("Kode Buku");
        model.addColumn("Nama Buku");
        model.addColumn("Pengarang");
        model.addColumn("Penerbit");
        model.addColumn("Tahun Terbit");
        model.addColumn("Harga Buku");
        model.addColumn("Stok");
        loadData();
        tbl_stok.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent evt) {
        int selectedRow = tbl_stok.getSelectedRow(); // Mendapatkan baris yang dipilih
        if (selectedRow != -1) { // Pastikan ada baris yang dipilih
            tf_kode_buku.setText(model.getValueAt(selectedRow, 0).toString()); 
            tf_nama_buku.setText(model.getValueAt(selectedRow, 1).toString()); 
            tf_pengarang.setText(model.getValueAt(selectedRow, 2).toString()); 
            tf_penerbit.setText(model.getValueAt(selectedRow, 3).toString()); 
            tf_tahun_terbit.setText(model.getValueAt(selectedRow, 4).toString()); 
            tf_harga_buku.setText(model.getValueAt(selectedRow, 5).toString()); 
            tf_stok.setText(model.getValueAt(selectedRow, 6).toString());
        }
    }
});
    }
    
    //Load Data Tabel stok
    public void loadData() {
        DefaultTableModel model = (DefaultTableModel) tbl_stok.getModel();
    model.setRowCount(0); // Hapus data lama
    try {
        String sql = "SELECT * FROM stok";
        Statement s = conn.createStatement();
        ResultSet r = s.executeQuery(sql);
        while (r.next()) {
            String kodeBuku = r.getString("kode_buku");
            String namaBuku = r.getString("nama_buku");
            String pengarang = r.getString("pengarang");
            String penerbit = r.getString("penerbit");
            String tahunTerbit = r.getString("tahun_terbit");
            String hargaBuku = r.getString("harga_buku");
            String stok = r.getString("stok");
            model.addRow(new Object[]{kodeBuku, namaBuku, pengarang, penerbit, tahunTerbit, hargaBuku, stok});
        }
        r.close();
        s.close();
    } catch (SQLException e) {
        System.out.println("Gagal Memuat Data: " + e.getMessage());
    }
    }
    //End Load Data Tabel stok
    
    
    
 public void autonumber(){
        try {
        conn = koneksi.getConnection();
        Statement s = conn.createStatement();
        String sql = "SELECT kode_buku FROM stok ORDER BY kode_buku DESC LIMIT 1";
        ResultSet r = s.executeQuery(sql);

        if (r.next()) {
            // Ambil angka di akhir kode_supp, apapun prefiksnya
            String kode_buku = r.getString("kode_buku").replaceAll("\\D", ""); // Hapus huruf
            int numKode = 0;
            try {
                numKode = Integer.parseInt(kode_buku);
            } catch (NumberFormatException e) {
                System.out.println("Format kode buku tidak valid: " + e.getMessage());
            }

            // Tambahkan 1 ke kode buku terakhir
            String BK = String.valueOf(numKode + 1);
            String Nol = "";

            if (BK.length() == 1) {
                Nol = "000";
            } else if (BK.length() == 2) {
                Nol = "00";
            } else if (BK.length() == 3) {
                Nol = "0";
            }

            tf_kode_buku.setText("BK" + Nol + BK);
        } else {
            // Jika tidak ada data, mulai dari BK0001
            tf_kode_buku.setText("BK0001");
        }
        r.close();
        s.close();
    } catch (SQLException e) {
        System.out.println("autonumber error: " + e.getMessage());
    }
    }
    
    
    //Simpan Data buku
    public void SimpanDataStok() {
    if (tf_kode_buku.getText().isEmpty() || tf_nama_buku.getText().isEmpty() || tf_pengarang.getText().isEmpty() || tf_penerbit.getText().isEmpty() || tf_tahun_terbit.getText().isEmpty() || tf_harga_buku.getText().isEmpty() || tf_stok.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi Data stok!");
        return;
    }
    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menambahkan data stok?", "Konfirmasi Tambah", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "INSERT INTO stok (kode_buku, nama_buku, pengarang, penerbit, tahun_terbit, harga_buku, stok ) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_kode_buku.getText());
            ps.setString(2, tf_nama_buku.getText());
            ps.setString(3, tf_pengarang.getText());
            ps.setString(4, tf_penerbit.getText());
            ps.setString(5, tf_tahun_terbit.getText());
            ps.setString(6, tf_harga_buku.getText());
            ps.setString(7, tf_stok.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Berhasil Disimpan");
            loadData();
            resetForm();
        } catch (SQLException e) {
            System.out.println("Gagal Menyimpan Data" + e.getMessage());
        }
    }
}
    //End Simpan Data buku
    
    //Update Data buku
    public void PerbaruiDataStok() {
     if (tf_nama_buku.getText().isEmpty() || tf_pengarang.getText().isEmpty() || tf_penerbit.getText().isEmpty() || tf_tahun_terbit.getText().isEmpty() || tf_harga_buku.getText().isEmpty() || tf_stok.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi data Buku Yang Akan Diubah!");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin mengubah data Buku?", "Konfirmasi Ubah", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "UPDATE stok SET nama_buku = ?, pengarang = ?, penerbit = ?, tahun_terbit = ?, harga_buku = ?, stok = ? WHERE kode_buku = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_nama_buku.getText());
            ps.setString(2, tf_pengarang.getText());
            ps.setString(3, tf_penerbit.getText());
            ps.setString(4, tf_tahun_terbit.getText());
            ps.setString(5, tf_harga_buku.getText());
            ps.setString(6, tf_stok.getText());
            ps.setString(7, tf_kode_buku.getText()); // Menggunakan kode buku sebagai kondisi
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Berhasil Diubah");
            loadData();
            resetForm();
        } catch (SQLException e) {
            System.out.println("Gagal Menyimpan Data: " + e.getMessage());
        }
    }
}
    //End Update Data buku
    
    //Delete Data buku
    public void HapusDataStok() {
    if (tf_kode_buku.getText().isEmpty()) {
    JOptionPane.showMessageDialog(this, "Tolong pilih buku yang akan dihapus!");
    return;
}

int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus data buku?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
if (confirm == JOptionPane.YES_OPTION) {
    try {
        String sql = "DELETE FROM stok WHERE kode_buku = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, tf_kode_buku.getText()); // Menggunakan setString untuk kode supplier
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Data Berhasil Dihapus");
        loadData();
        resetForm();
    } catch (SQLException e) {
        System.out.println("Gagal Menghapus Data Supplier: " + e.getMessage());
    }
    }
}
    //End Delete Data buku
    
    public JTable getTblStok() {
    return tbl_stok;
}

    
    public void resetForm(){
        tf_kode_buku.setText("");
        tf_nama_buku.setText("");
        tf_pengarang.setText("");
        tf_penerbit.setText("");
        tf_tahun_terbit.setText("");
        tf_harga_buku.setText("");
        tf_stok.setText("");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        tf_kode_buku = new javax.swing.JTextField();
        tf_penerbit = new javax.swing.JTextField();
        tf_nama_buku = new javax.swing.JTextField();
        tf_pengarang = new javax.swing.JTextField();
        tf_tahun_terbit = new javax.swing.JTextField();
        tf_harga_buku = new javax.swing.JTextField();
        tf_stok = new javax.swing.JTextField();
        tf_search_stok = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_stok = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btn_tambah_stok = new javax.swing.JButton();
        btn_simpan_stok = new javax.swing.JButton();
        btn_perbarui_stok = new javax.swing.JButton();
        btn_hapus_stok = new javax.swing.JButton();

        setTitle("STOK");
        setPreferredSize(new java.awt.Dimension(888, 427));

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(34, 92, 127));
        jLabel8.setText("Kode Buku");

        jLabel9.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(34, 92, 127));
        jLabel9.setText("Nama Buku");

        jLabel10.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(34, 92, 127));
        jLabel10.setText("Pengarang");

        jLabel11.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(34, 92, 127));
        jLabel11.setText("Penerbit");

        jLabel12.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(34, 92, 127));
        jLabel12.setText("Tahun Terbit");

        jLabel13.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(34, 92, 127));
        jLabel13.setText("Harga Buku");

        jLabel14.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(34, 92, 127));
        jLabel14.setText("Stok");

        tf_kode_buku.setEditable(false);

        tf_search_stok.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf_search_stok.setText("SEARCH BERDASARKAN NAMA BUKU");
        tf_search_stok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_search_stokActionPerformed(evt);
            }
        });

        tbl_stok.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode Buku", "Nama Buku", "Pengarang", "Penerbit", "Tahun Terbit", "Harga Buku", "Stok"
            }
        ));
        jScrollPane1.setViewportView(tbl_stok);

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        btn_tambah_stok.setBackground(new java.awt.Color(34, 92, 127));
        btn_tambah_stok.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_tambah_stok.setForeground(new java.awt.Color(255, 255, 255));
        btn_tambah_stok.setText("Kode Buku");
        btn_tambah_stok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambah_stokActionPerformed(evt);
            }
        });
        jPanel1.add(btn_tambah_stok);

        btn_simpan_stok.setBackground(new java.awt.Color(34, 92, 127));
        btn_simpan_stok.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_simpan_stok.setForeground(new java.awt.Color(255, 255, 255));
        btn_simpan_stok.setText("Simpan");
        btn_simpan_stok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpan_stokActionPerformed(evt);
            }
        });
        jPanel1.add(btn_simpan_stok);

        btn_perbarui_stok.setBackground(new java.awt.Color(34, 92, 127));
        btn_perbarui_stok.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_perbarui_stok.setForeground(new java.awt.Color(255, 255, 255));
        btn_perbarui_stok.setText("Perbarui");
        btn_perbarui_stok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_perbarui_stokActionPerformed(evt);
            }
        });
        jPanel1.add(btn_perbarui_stok);

        btn_hapus_stok.setBackground(new java.awt.Color(34, 92, 127));
        btn_hapus_stok.setFont(new java.awt.Font("Eras Bold ITC", 0, 12)); // NOI18N
        btn_hapus_stok.setForeground(new java.awt.Color(255, 255, 255));
        btn_hapus_stok.setText("Hapus");
        btn_hapus_stok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapus_stokActionPerformed(evt);
            }
        });
        jPanel1.add(btn_hapus_stok);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tf_kode_buku)
                    .addComponent(tf_nama_buku, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tf_penerbit)
                    .addComponent(tf_pengarang, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tf_harga_buku, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tf_tahun_terbit, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(tf_stok, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_search_stok)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10)
                            .addComponent(jLabel12)
                            .addComponent(jLabel14)
                            .addComponent(tf_pengarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_tahun_terbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_stok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel13)
                            .addComponent(tf_penerbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_nama_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_harga_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tf_kode_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_search_stok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tf_search_stokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_search_stokActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_search_stokActionPerformed

    private void btn_perbarui_stokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_perbarui_stokActionPerformed
        // TODO add your handling code here:
        PerbaruiDataStok();
    }//GEN-LAST:event_btn_perbarui_stokActionPerformed

    private void btn_tambah_stokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambah_stokActionPerformed
        // TODO add your handling code here:
        autonumber();
    }//GEN-LAST:event_btn_tambah_stokActionPerformed

    private void btn_simpan_stokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpan_stokActionPerformed
        // TODO add your handling code here:
        SimpanDataStok();
    }//GEN-LAST:event_btn_simpan_stokActionPerformed

    private void btn_hapus_stokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapus_stokActionPerformed
        // TODO add your handling code here:
        HapusDataStok();
    }//GEN-LAST:event_btn_hapus_stokActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_hapus_stok;
    private javax.swing.JButton btn_perbarui_stok;
    private javax.swing.JButton btn_simpan_stok;
    private javax.swing.JButton btn_tambah_stok;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_stok;
    private javax.swing.JTextField tf_harga_buku;
    private javax.swing.JTextField tf_kode_buku;
    private javax.swing.JTextField tf_nama_buku;
    private javax.swing.JTextField tf_penerbit;
    private javax.swing.JTextField tf_pengarang;
    private javax.swing.JTextField tf_search_stok;
    private javax.swing.JTextField tf_stok;
    private javax.swing.JTextField tf_tahun_terbit;
    // End of variables declaration//GEN-END:variables
}
